import os
os.system("python E:\\backup\\swat_2.7\\swat_2.7\\swat.py" )