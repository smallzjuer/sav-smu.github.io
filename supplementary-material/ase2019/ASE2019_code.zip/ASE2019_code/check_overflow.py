#!/usr/bin/env python2

"""
Use pycomm python2 module to communicate with contrologix PLCs

adapted from: examples/test_ab_comm.py
more on: https://github.com/ruscito/pycomm
"""

# import logging
import time
import string
import datetime

from pycomm.ab_comm.clx import Driver as ClxDriver
import os

PLC_IPS = {
    'plc1': '192.168.1.10',
    'tag_plc1': ['HMI_LIT101.Pv', 'AI_FIT_101_FLOW', 'HMI_LIT101.Sim_Pv'],
    'plc2': '192.168.1.20',
    'plc3': '192.168.1.30',
    'tag_plc3': ['HMI_LIT301.Pv', 'AI_FIT_301_FLOW'],
    'plc4': '192.168.1.40',
    'tag_plc4': ['HMI_LIT401.Pv', 'AI_FIT_401_FLOW'],
    'plc5': '192.168.1.50',
    'plc6': '192.168.1.60',
    'plc1r': '192.168.1.11',
    'plc2r': '192.168.1.21',
    'plc3r': '192.168.1.31',
    'plc4r': '192.168.1.41',
    'plc5r': '192.168.1.51',
    'plc6r': '192.168.1.61',
}


# init client
# logging.basicConfig(
#     filename="plc.log",
#     # level=logging.WARNING,
#     level=logging.DEBUG,  # more verbosity
#     format="%(levelname)-10s %(asctime)s %(message)s"
# )


def test_plc_write(plc_ip, tag_name, value, tag_type):
    """Write a plc tag and print a BOOL status code.

    :plc_ip: TODO
    :tag_name: TODO
    :value: TODO
    :tag_type: TODO

    """
    plc = ClxDriver()
    if plc.open(plc_ip):
        print(plc.write_tag(tag_name, value, tag_type))
        plc.close()
    else:
        print("Unable to open", plc_ip)


def test_plc_read(plc_ip, tag_name):
    """Read a plc tag and print the rx data

    :plc_ip:
    :tag_name:
    """

    plc = ClxDriver()
    if plc.open(plc_ip):

        print(plc.read_tag(tag_name))
        # plc.read_tag(tag_name)
        plc.close()
    else:
        print("Unable to open", plc_ip)


def test_plc_read_val(plc_ip, tag_name):
    """Read a plc tag and print the rx data

    :plc_ip:
    :tag_name:
    """

    plc = ClxDriver()
    if plc.open(plc_ip):
        tagg = plc.read_tag(tag_name)
        plc.close()
        return (tagg)

    else:
        print("Unable to open", plc_ip)


def main():
    """ Read and write PLCs tags using pycomm.

    DI_P_201* tags are configured as external tags with
    read/write permission. PLC2 will re-scan and re-write
    their value according to a set of state variables.

    dummy and dummy_int are configured as external tags
    with read/write permissions and they serve as a proof
    that pycomm can effectivley read and write tag using
    ENIP.
    """
    ## real SWAT tags


##LIT101

# a=a+1000

# test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Auto', 0 , 'BOOL')
# test_plc_write(PLC_IPS['plc1'], 'HMI_MV101.Cmd', 1, 'INT')
while (True):

    a = test_plc_read_val(PLC_IPS['plc1'], 'HMI_LIT101.Pv')

    b = test_plc_read_val(PLC_IPS['plc3'], 'HMI_LIT301.Pv')

    c = test_plc_read_val(PLC_IPS['plc4'], 'HMI_LIT401.Pv')

    print "LIT101",a[0]
    if a[0]>1000:
        print "LIT101 is overflow"
    if a[0]<250:
        print "LIT101 is underflow"
    print "LIT301",b[0]
    if b[0] > 1200:
        print "LIT301 is overflow"
    if b[0] < 250:
        print "LIT301 is underflow"
    print "LIT401", c[0]
    if c[0] > 1100:
        print "LIT401 is overflow"
    if c[0] < 250:
        print "LIT401 is underflow"
    log_path = os.getcwd() + "\\alarm.txt"
    with open(log_path, 'a') as f:
        if a[0] > 1000:
            f.write("LIT101 is overflow"+"\n")
        if a[0] < 250:
            f.write("LIT101 is underflow"+"\n")
        if b[0] > 1200:
            f.write("LIT301 is overflow"+"\n")
        if b[0] < 250:
            f.write("LIT301 is underflow"+"\n")
        if c[0] > 1100:
            f.write("LIT401 is overflow"+"\n")
        if c[0] < 250:
            f.write("LIT401 is underflow"+"\n")
        f.write("LIT101:"+str(a[0])+"\n")
        f.write("LIT301:"+str(b[0])+"\n")
        f.write("LIT401:"+str(c[0])+"\n")

    # print d
    time.sleep(60)


if __name__ == '__main__':
    main()
