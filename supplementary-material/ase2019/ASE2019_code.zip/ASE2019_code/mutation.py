import random


def mutation(dna,indpb):
    if random.random() < indpb:
        mut_index=random.randint(0,len(dna)-1)
        if dna[mut_index]==1:
            dna[mut_index]=2
        else:
            dna[mut_index]=1
    return dna


# if __name__=='__main__':
#     indpb=1
#     dna=[1,2,2,1,1,1]
#     print dna
#     print mutation(dna,1)
