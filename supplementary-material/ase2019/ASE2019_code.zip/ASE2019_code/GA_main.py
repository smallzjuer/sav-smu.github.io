import os
import numpy as np
import selection
from crossover import crossover
from mutation import mutation
from population import population
import pickle


def GA_algorithm(num_actuators, Initial_sensor, number_of_sensor, num_of_ind, Upperbound, Lowerbound, model_path,
                      model_type,pm,r,num_parents, num_generations):
    pop1 = population(num_actuators, Initial_sensor, number_of_sensor, num_of_ind, Upperbound, Lowerbound, model_path,
                      model_type)
    pop1.actuatorEncoding()
    pop1.generateInd()
    best_result = []
    largest = 0
    for generation in range(num_generations):
        print "Generation : ", generation
        # calculate the fitness of each chromosome in the population.
        pop1.fitness_fn()
        # print pop1.fitness
        # The best result in the current iteration.
        best = selection.find_best(pop1.fitness)
        best = pop1.pop[best[0]], best[1]
        print best
        best_result.append(best)
        # Selecting the parents in the population for mating.
        new_actuator_set = []
        sel = []
        for i in range(num_parents):
            sel.append(selection.selection(pop1))

        # print sel
        # for i in range(100):
        #     print pop1.actuator_set[sel[i]]
        for i in range(num_parents / 2):
            new_actuator_set.append(pop1.actuator_set[sel[2 * i]])
            new_actuator_set.append(pop1.actuator_set[sel[2 * i + 1]])
            crossover(new_actuator_set[2 * i], new_actuator_set[2 * i + 1])

            # print new_actuator_set

            #         # two_points_crossover(new_actuator_set[2 * i], new_actuator_set[2 * i + 1])
            #     # Generating next generation using crossover.
        new_pop = population(num_actuators, Initial_sensor, number_of_sensor, num_of_ind, Upperbound, Lowerbound,
                             model_path, model_type)
        for i in range(len(new_actuator_set)):
            mutation(new_actuator_set[i], pm)
            new_pop.actuator_set.append(new_actuator_set[i])  # mutation.
            #     #
        pop1.actuator_set = new_pop.actuator_set
        pop1.generateInd()
        # Creating the new population
        if generation>0:
            if best_result[generation][1]>best_result[largest][1]:
                largest = generation

        print largest

        if generation-largest>r:
            pop1.actuatorEncoding()

    print("Best result : ", best_result)
    actuator_array = best_result[largest][0][1:]

    return actuator_array


