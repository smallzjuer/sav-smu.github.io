import random
import chrome
import pickle
import numpy as np
import os
class population:
    pop=[]
    actuator_set=[]
    fitness=[]

    def __init__(self,*arg):
        if len(arg)==8:
            self.number_of_actuators=arg[0]
            self.initial_sensor=arg[1]
            self.number_of_sensor=arg[2]
            self.number_of_individual=arg[3]
            self.Upperbound=arg[4]
            self.Lowerbound=arg[5]
            self.model_path=arg[6]
            self.model_type=arg[7]    # 0: svr 1:lstm
        else:
            print "error"
        self.pop = []
        self.actuator_set = []
        self.fitness=[]



    def actuatorEncoding(self):
        actuatorset = []
        for i in range(self.number_of_individual):
            temp = []
            for j in range(0,self.number_of_actuators):
                temp.append(random.randint(1, 2))
            actuatorset.append(temp)
            self.actuator_set=actuatorset[0:]
        return actuatorset[0:]


    def generateInd(self):
        self.pop=[]
        for i in range(len(self.actuator_set)):
            t = []
            t.append(self.initial_sensor)
            for j in range(self.number_of_actuators):
                t.append(self.actuator_set[i][j])
            self.pop.append(t)

        return self.pop

    def predict_svm(self):
        new_sensor = []
        if self.number_of_sensor==1:
            with open(self.model_path, 'rb') as fid:
                svr_model = pickle.load(fid)
            for i in range(0, len(self.actuator_set)):
                t = []
                t = self.pop[i][1:]
                t.insert(0, self.pop[i][0][0])
                x = np.array(t)
                y = svr_model.predict(x.reshape(1, -1))
                new_sensor.append(float(y[0]))
            return new_sensor

        else:
            for j in range(self.number_of_sensor):
                new_sensor.append([])
            for j in range(self.number_of_sensor):
                with open(self.model_path[j], 'rb') as fid:
                    svr_model = pickle.load(fid)
                for i in range(0, len(self.actuator_set)):
                    t = []
                    t = self.pop[i][1:]
                    t.insert(0, self.pop[i][0][j])
                    x = np.array(t)
                    y = svr_model.predict(x.reshape(1, -1))
                    new_sensor[j].append(float(y[0]))
            return new_sensor


    def predict_lstm(self):
        pass

    # def predict_lstm(self):
    #     new_sensor = []
    #     with open(self.model_path, 'rb') as fid:
    #         lstm_model = pickle.load(fid)
    #     for i in range(0, len(self.actuator_set)):
    #         x = np.array(self.pop[i])
    #         forecast_lstm(lstm_model, x, y)
    #         new_sensor.append(float(y[0]))
    #     return new_sensor

    def fitness_fn(self):
        self.fitness=[]
        v=0
        if self.model_type==0:
            new_sensor_value = self.predict_svm()
        else:
            new_sensor_value=self.predict_lstm()

        if self.number_of_sensor==1:
            for i in range(len(new_sensor_value)):
                v = self.fitness_function(new_sensor_value[i],self.Upperbound,self.Lowerbound)
                self.fitness.append(v)

        else:
            for i in range(len(new_sensor_value[0])):
                for j in range(self.number_of_sensor):
                    v = v+self.fitness_function(new_sensor_value[j][i],self.Upperbound[j],self.Lowerbound[j])
                    # print v
                self.fitness.append(v)
                v=0


        return self.fitness

    def fitness_function(self, sensor_value,HH,LoLo):
        if sensor_value >= HH:
            return float("inf")
        else:
            if sensor_value <= LoLo:
                return float("inf")
            else:
                return 1 / (1 - abs(sensor_value - (HH + LoLo) / 2) / (
                        HH / 2 - LoLo / 2))

    # def survivor_selection(self):
    #     if len(self.fitness)==self.number_of_individual:
    #         print "error"
    #     else:
    #         print self.fitness
    #         new_list= sorted(self.fitness)
    #         print new_list
    #         # for i in range( len(self.actuator_set)-self.number_of_individual):
    #         #     index= self.fitness().index(new_list[i])
    #         #     del self.pop[index]
    #         #     del self.actuator_set[index]
    #         #     del self.fitness
    #         # return self.pop
