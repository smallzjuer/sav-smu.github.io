class Chrom:
    actuator = []
    sensor=[]
    fitness = 0
    def showSensor (self):
        print(self.sensor)
    def showActuator(self):
        print(self.actuator)
    def showFitness(self):
        print(self.fitness)
if __name__ == '__main__':
    pass