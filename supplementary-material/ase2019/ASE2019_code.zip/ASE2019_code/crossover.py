import math
import random

def two_points_crossover(dna1, dna2):
    length=len(dna1)
    t=random.random()
    length1=int(math.ceil(length*t))
    length2=length-length1
    crossoverpoint1=int(math.ceil(length1/2))
    crossoverpoint2 = int(math.ceil(length2 / 2))
    for i in range(0, crossoverpoint1):
        temp=dna1[i]
        dna1[i]=dna2[i]
        dna2[i]=temp

    for i in range(length1, crossoverpoint2+length1):
        temp=dna1[i]
        dna1[i]=dna2[i]
        dna2[i]=temp

    return dna1,dna2


def crossover(dna1,dna2):
    length=len(dna1)
    # crossoverpoint = random.randint(int(math.ceil(length / 2)))
    crossoverpoint=random.randint(0,len(dna1))
    # print crossoverpoint
    for i in range(0, crossoverpoint):
        temp=dna1[i]
        dna1[i]=dna2[i]
        dna2[i]=temp

    return dna1,dna2
