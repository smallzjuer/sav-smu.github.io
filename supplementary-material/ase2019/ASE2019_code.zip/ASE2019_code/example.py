
from GA_main import GA_algorithm
from actuator_configure import configure_function
from actuator_configure import get_sensor_value
import os



if __name__ == '__main__':
    sensor=get_sensor_value()
    Initial_sensor=[]
    Initial_sensor.append(sensor[1])
    Initial_sensor.append(sensor[3])
    # Inputs of the sensor.
    model_path = []
    model_path.append(os.getcwd() + "\lit101")
    model_path.append(os.getcwd() + "\lit301")
    num_generations=100
    number_of_sensor = 2
    Upperbound = [1000, 1000]
    Lowerbound = [200, 200]
    # Number of the actuators we are looking to optimize.
    num_actuators = 26
    pm = 0.1  # probability of mutation
    r = 10  # randomly generate new population if no improvement in the population for r iterations. O means reach the mix iterations
    num_of_ind = 100# Population size
    num_parents = 100
    model_type = 0
    position = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]
    start_point=0
    attack_array=GA_algorithm(num_actuators, Initial_sensor, number_of_sensor, num_of_ind, Upperbound, Lowerbound, model_path,
                 model_type, pm, r, num_parents, num_generations)
    length=len(attack_array)
    configure_function(attack_array,position)
