#!/usr/bin/env python2

__AUTHOR__ = "Yuqi"
import time

# Need ZeroMQ as the transport protocol
# instructions in requirements.md
import zmq



# Allen-Bradley driver to communicate with the PLC
from pycomm.ab_comm.clx import Driver as ClxDriver

# String ooperations on the incoming messages
import string

# open the file for recording LIC and PLC data
# logger = open(datetime.datetime.now().ctime() + '.csv', 'w+')
logger = open('log_sj.csv', 'w+')

# PLC IP addresses
PLC_IPS_p1 = {'plc1': '192.168.1.10', 'tag_plc1': [
    'AI_LIT_101_LEVEL', 'AI_FIT_101_FLOW', 'DI_P_101_AUTO', 'DI_P_101_RUN', 'DI_P_101_FAULT', 'DI_P_102_AUTO',
    'DI_P_102_RUN', 'DI_P_102_FAULT', 'DI_MV_101_ZSO', 'DI_MV_101_ZSC', 'DO_P_101_START', 'DO_P_102_START',
    'DO_MV_101_OPEN', 'DO_MV_101_CLOSE']}
PLC_IPS_p2_1 = {'plc2': '192.168.1.20', 'tag_plc2': [
    'AI_FIT_201_FLOW', 'AI_AIT_201_COND', 'AI_AIT_202_PH', 'AI_AIT_203_ORP', 'DI_P_201_AUTO', 'DI_P_201_RUN',
    'DI_P_201_FAULT', 'DI_P_202_AUTO', 'DI_P_202_RUN', 'DI_P_202_FAULT', 'DI_P_203_AUTO', 'DI_P_203_RUN',
    'DI_P_203_FAULT', 'DI_P_204_AUTO', 'DI_P_204_RUN', 'DI_P_204_FAULT', 'DI_P_205_AUTO', 'DI_P_205_RUN',
    'DI_P_205_FAULT', 'DI_P_206_AUTO', 'DI_P_206_RUN']}

PLC_IPS_p2_2 = {'plc2': '192.168.1.20', 'tag_plc2': ['DI_P_206_FAULT']}

PLC_IPS_p2_3 = {'plc2': '192.168.1.20', 'tag_plc2': [
    'DI_P_207_AUTO', 'DI_P_207_RUN', 'DI_P_207_FAULT', 'DI_P_208_AUTO', 'DI_P_208_RUN', 'DI_P_208_FAULT',
    'DI_MV_201_ZSO', 'DI_MV_201_ZSC', 'DI_LS_201_LOW', 'DI_LS_202_LOW', 'DI_LS_203_LOW', 'DI_LS_203_LOWLOW',
    'DO_P_201_START', 'DO_P_202_START', 'DO_P_203_START', 'DO_P_204_START', 'DO_P_205_START', 'DO_P_206_START',
    'DO_P_207_START', 'DO_P_208_START', 'DO_MV_201_OPEN', 'DO_MV_201_CLOSE']}

PLC_IPS_p3_1 = {'plc3': '192.168.1.30', 'tag_plc3': [
    'AI_LIT_301_LEVEL', 'AI_FIT_301_FLOW', 'AI_DPIT_301_DPRESS', 'DI_P_301_AUTO', 'DI_P_301_RUN', 'DI_P_301_FAULT',
    'DI_P_302_AUTO', 'DI_P_302_RUN', 'DI_P_302_FAULT', 'DI_MV_301_ZSO', 'DI_MV_301_ZSC', 'DI_MV_302_ZSO',
    'DI_MV_302_ZSC', 'DI_MV_303_ZSO', 'DI_MV_303_ZSC', 'DI_MV_304_ZSO', 'DI_MV_304_ZSC', 'DI_PSH_301_HIGH',
    'DI_DPSH_301_HIGH']}

PLC_IPS_p3_2 = {'plc3': '192.168.1.30', 'tag_plc3': [
    'DO_P_301_START', 'DO_P_302_START', 'DO_MV_301_OPEN', 'DO_MV_301_CLOSE', 'DO_MV_302_OPEN', 'DO_MV_302_CLOSE',
    'DO_MV_303_OPEN', 'DO_MV_303_CLOSE', 'DO_MV_304_OPEN', 'DO_MV_304_CLOSE']}

PLC_IPS_p4_1 = {'plc4': '192.168.1.40', 'tag_plc4': [
    'AI_LIT_401_LEVEL', 'AI_AIT_401_HRDNSS', 'AI_FIT_401_FLOW', 'AI_AIT_402_ORP', 'DI_P_401_AUTO', 'DI_P_401_RUN',
    'DI_P_401_FAULT', 'DI_P_402_AUTO', 'DI_P_402_RUN', 'DI_P_402_FAULT', 'DI_P_403_AUTO', 'DI_P_403_RUN',
    'DI_P_403_FAULT', 'DI_P_404_AUTO', 'DI_P_404_RUN', 'DI_P_404_FAULT', 'DI_UV_401_AUTO', 'DI_UV_401_RUN',
    'DI_UV_401_FAULT', 'DI_LS_401_LOW']}

PLC_IPS_p4_2 = {'plc4': '192.168.1.40', 'tag_plc4': [
    'DO_P_401_START', 'DO_P_402_START', 'DO_P_403_START', 'DO_P_404_START', 'DO_UV_401_START']}

PLC_IPS_p5_1 = {'plc5': '192.168.1.50', 'tag_plc5': [
    'AI_AIT_501_PH', 'AI_AIT_502_ORP', 'AI_AIT_503_COND', 'AI_AIT_504_COND', 'AI_FIT_501_FLOW', 'AI_FIT_502_FLOW',
    'AI_FIT_503_FLOW', 'AI_FIT_504_FLOW', 'AI_PIT_501_PRESS', 'AI_PIT_502_PRESS', 'AI_PIT_503_PRESS']}
PLC_IPS_p5_2 = {'plc5': '192.168.1.50', 'tag_plc5': [
    'DI_P_501_AUTO', 'DI_P_501_FAULT', 'DI_P_501_RUN', 'DI_P_502_AUTO', 'DI_P_502_FAULT', 'DI_P_502_RUN',
    'DI_MV_501_ZSO', 'DI_MV_501_ZSC', 'DI_MV_502_ZSO', 'DI_MV_502_ZSC', 'DI_MV_503_ZSO', 'DI_MV_503_ZSC',
    'DI_MV_504_ZSO', 'DI_MV_504_ZSC', 'DI_PSL_501_LOW', 'DI_PSH_501_HIGH', 'DI_VSD_1_PB', 'DI_VSD_2_PB']}
PLC_IPS_p5_3 = {'plc5': '192.168.1.50', 'tag_plc5': [
    'DO_MV_501_OPEN', 'DO_MV_501_CLOSE', 'DO_MV_502_OPEN', 'DO_MV_502_CLOSE', 'DO_MV_503_OPEN', 'DO_MV_503_CLOSE',
    'DO_MV_504_OPEN', 'DO_MV_504_CLOSE']}
PLC_IPS_p6 = {'plc6': '192.168.1.60', 'tag_plc6': [
    'DI_P_601_AUTO', 'DI_P_601_RUN', 'DI_P_601_FAULT', 'DI_P_602_AUTO', 'DI_P_602_RUN', 'DI_P_602_FAULT',
    'DI_P_603_AUTO', 'DI_P_603_RUN', 'DI_P_603_FAULT', 'DI_LS_601_LOW', 'DI_LS_601_HIGH', 'DI_LS_602_LOW',
    'DI_LS_602_HIGH', 'DI_LS_603_LOW', 'DI_LS_603_HIGH', 'AI_FIT_601_FLOW', 'DO_P_601_START', 'DO_P_602_START',
    'DO_P_603_START']}


# Read PLC Values for the configured tags
def test_plc_read_val(plc_ip, tag_name):
    plc = ClxDriver()
    if plc.open(plc_ip):
        tagg = plc.read_tag(tag_name)
        plc.close()
        return (tagg)
    else:
        print("Unable to open", plc_ip)



